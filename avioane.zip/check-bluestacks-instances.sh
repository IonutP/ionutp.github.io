#!/bin/bash

echo "Checking BlueStacks instances..."
echo ""

# Kill and restart ADB server
echo "Restarting ADB server..."
adb kill-server
sleep 2
adb start-server
sleep 2

echo ""
echo "Connected devices:"
adb devices

echo ""
echo "If you only see one device, try:"
echo "1. Open BlueStacks Settings → Advanced → Enable Android Debug Bridge (ADB) on BOTH instances"
echo "2. Note the ADB port for each instance (usually shown in BlueStacks settings)"
echo "3. Restart both BlueStacks instances"
echo "4. Run this script again"

