const { execSync, exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const readline = require('readline');
const Tesseract = require('tesseract.js');
const sharp = require('sharp');

class BlueStacksAutomation {
    constructor(deviceId = null) {
        this.deviceId = deviceId;
        // Create screenshots directory if it doesn't exist
        this.screenshotsDir = path.join(__dirname, 'screenshots');
        if (!fs.existsSync(this.screenshotsDir)) {
            fs.mkdirSync(this.screenshotsDir, { recursive: true });
        }
        this.screenshotPath = path.join(this.screenshotsDir, 'screenshot.png');
        this.adbPath = this.findAdbPath();
    }

    /**
     * Find ADB path - tries common locations
     */
    findAdbPath() {
        const isWindows = process.platform === 'win32';
        const possiblePaths = [
            'adb', // If in PATH
            // macOS/Linux paths
            '/usr/local/bin/adb',
            '/opt/homebrew/bin/adb',
            process.env.ANDROID_HOME ? `${process.env.ANDROID_HOME}/platform-tools/adb${isWindows ? '.exe' : ''}` : null,
            process.env.ANDROID_SDK_ROOT ? `${process.env.ANDROID_SDK_ROOT}/platform-tools/adb${isWindows ? '.exe' : ''}` : null,
            // Windows paths
            ...(isWindows ? [
                'C:\\Program Files\\Android\\android-sdk\\platform-tools\\adb.exe',
                'C:\\Users\\' + process.env.USERNAME + '\\AppData\\Local\\Android\\Sdk\\platform-tools\\adb.exe',
                process.env.LOCALAPPDATA ? `${process.env.LOCALAPPDATA}\\Android\\Sdk\\platform-tools\\adb.exe` : null,
            ] : []),
        ].filter(Boolean);

        for (const adbPath of possiblePaths) {
            try {
                execSync(`${adbPath} version`, { stdio: 'ignore' });
                return adbPath;
            } catch (e) {
                // Continue searching
            }
        }

        // If not found, assume it's in PATH
        return 'adb';
    }

    /**
     * Execute ADB command
     */
    async adbCommand(command) {
        const fullCommand = this.deviceId 
            ? `${this.adbPath} -s ${this.deviceId} ${command}`
            : `${this.adbPath} ${command}`;
        
        return new Promise((resolve, reject) => {
            exec(fullCommand, (error, stdout, stderr) => {
                if (error) {
                    reject(new Error(`ADB command failed: ${stderr || error.message}`));
                } else {
                    resolve(stdout.trim());
                }
            });
        });
    }

    /**
     * Check if device is connected
     */
    async checkConnection() {
        const maxRetries = 3;
        let lastError = null;
        
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                let devices = await this.getDevices();
                
                // If no devices found and this is not the last attempt, try restarting ADB
                if (devices.length === 0 && attempt < maxRetries) {
                    console.log(`\n⚠️  No devices found (attempt ${attempt}/${maxRetries})`);
                    const restarted = await this.restartAdbServer();
                    if (restarted) {
                        // Wait a bit and try again
                        await new Promise(resolve => setTimeout(resolve, 2000));
                        devices = await this.getDevices();
                    }
                }
                
                if (devices.length === 0) {
                    if (attempt === maxRetries) {
                        throw new Error('No devices found. Make sure BlueStacks is running and ADB debugging is enabled.');
                    }
                    continue; // Try again
                }
                
                // If device ID is explicitly set, validate it
                if (this.deviceId && !devices.includes(this.deviceId)) {
                    throw new Error(`Device ${this.deviceId} not found. Available devices: ${devices.join(', ')}`);
                }

                // If no device ID is set and multiple devices are present, prompt user to select
                if (!this.deviceId && devices.length > 1) {
                    const selectedDevice = await this.selectDevice(devices);
                    this.deviceId = selectedDevice;
                } else if (!this.deviceId) {
                    // Only one device, use it automatically
                    this.deviceId = devices[0];
                }

                console.log(`✅ Connected to device: ${this.deviceId}`);
                return true;
            } catch (error) {
                lastError = error;
                if (attempt < maxRetries) {
                    console.log(`\n⚠️  Connection attempt ${attempt}/${maxRetries} failed, retrying...`);
                    await new Promise(resolve => setTimeout(resolve, 2000));
                }
            }
        }
        
        // If we get here, all retries failed
        console.error(`❌ Connection error after ${maxRetries} attempts: ${lastError.message}`);
        console.log('\n💡 Troubleshooting tips:');
        console.log('   1. Make sure BlueStacks is running');
        console.log('   2. Enable ADB debugging in BlueStacks Settings → Advanced');
        console.log('   3. Try manually running: adb kill-server && adb start-server');
        console.log('   4. Check if devices appear: adb devices');
        throw lastError;
    }

    /**
     * Restart ADB server
     */
    async restartAdbServer() {
        try {
            console.log('🔄 Restarting ADB server...');
            
            // Kill ADB server
            try {
                await new Promise((resolve, reject) => {
                    exec(`${this.adbPath} kill-server`, (error, stdout, stderr) => {
                        // Ignore errors - server might not be running
                        resolve();
                    });
                });
            } catch (e) {
                // Ignore errors
            }
            
            // Wait a moment
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            // Start ADB server
            await new Promise((resolve, reject) => {
                exec(`${this.adbPath} start-server`, (error, stdout, stderr) => {
                    if (error) {
                        reject(new Error(`Failed to start ADB server: ${stderr || error.message}`));
                    } else {
                        resolve();
                    }
                });
            });
            
            // Wait a moment for server to be ready
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            console.log('✅ ADB server restarted');
            return true;
        } catch (error) {
            console.error(`⚠️  Failed to restart ADB server: ${error.message}`);
            return false;
        }
    }

    /**
     * Get list of connected devices
     */
    async getDevices() {
        try {
            // Use adb directly without device ID to get all devices
            const fullCommand = `${this.adbPath} devices`;
            const output = await new Promise((resolve, reject) => {
                exec(fullCommand, (error, stdout, stderr) => {
                    if (error) {
                        reject(new Error(`ADB command failed: ${stderr || error.message}`));
                    } else {
                        resolve(stdout.trim());
                    }
                });
            });
            const lines = output.split('\n').slice(1); // Skip header
            return lines
                .filter(line => line.trim() && line.includes('device'))
                .map(line => line.split('\t')[0]);
        } catch (error) {
            console.error('Error getting devices:', error.message);
            return [];
        }
    }

    /**
     * Prompt user to select a device when multiple devices are present
     */
    async selectDevice(devices) {
        return new Promise((resolve, reject) => {
            const rl = readline.createInterface({
                input: process.stdin,
                output: process.stdout
            });

            console.log('\n📱 Multiple devices detected:');
            devices.forEach((device, index) => {
                console.log(`   ${index + 1}. ${device}`);
            });

            const askQuestion = () => {
                rl.question(`\nSelect a device (1-${devices.length}): `, (answer) => {
                    const selection = parseInt(answer.trim(), 10);
                    
                    if (isNaN(selection) || selection < 1 || selection > devices.length) {
                        console.log(`❌ Invalid selection. Please enter a number between 1 and ${devices.length}.`);
                        askQuestion();
                        return;
                    }

                    const selectedDevice = devices[selection - 1];
                    rl.close();
                    resolve(selectedDevice);
                });
            };

            askQuestion();
        });
    }

    /**
     * Take a screenshot of the device
     */
    async takeScreenshot(savePath = null) {
        try {
            const outputPath = savePath || this.screenshotPath;
            const tempPath = '/sdcard/screenshot.png';
            
            // Method 1: Save to device then pull (most reliable)
            try {
                await this.adbCommand(`shell screencap -p ${tempPath}`);
                await this.adbCommand(`pull ${tempPath} ${outputPath}`);
                await this.adbCommand(`shell rm ${tempPath}`);
            } catch (e) {
                // Method 2: Use exec-out with shell redirection
                const fullCommand = this.deviceId 
                    ? `${this.adbPath} -s ${this.deviceId} exec-out screencap -p > ${outputPath}`
                    : `${this.adbPath} exec-out screencap -p > ${outputPath}`;
                
                execSync(fullCommand, { stdio: 'ignore' });
            }

            if (!fs.existsSync(outputPath)) {
                throw new Error('Screenshot file was not created');
            }

            return outputPath;
        } catch (error) {
            console.error(`❌ Screenshot error: ${error.message}`);
            throw error;
        }
    }

    /**
     * Click on specific coordinates
     */
    async click(x, y, delay = 100) {
        try {
            await this.adbCommand(`shell input tap ${x} ${y}`);
            await this.sleep(delay);
        } catch (error) {
            console.error(`❌ Click error: ${error.message}`);
            throw error;
        }
    }

    /**
     * Swipe from one point to another
     */
    async swipe(x1, y1, x2, y2, duration = 300) {
        try {
            await this.adbCommand(`shell input swipe ${x1} ${y1} ${x2} ${y2} ${duration}`);
            console.log(`👆 Swiped from (${x1}, ${y1}) to (${x2}, ${y2})`);
            await this.sleep(300);
        } catch (error) {
            console.error(`❌ Swipe error: ${error.message}`);
            throw error;
        }
    }

    /**
     * Type text
     */
    async typeText(text) {
        try {
            // Escape special characters for shell
            const escapedText = text.replace(/ /g, '%s').replace(/&/g, '\\&');
            await this.adbCommand(`shell input text "${escapedText}"`);
            console.log(`⌨️  Typed: ${text}`);
        } catch (error) {
            console.error(`❌ Type text error: ${error.message}`);
            throw error;
        }
    }

    /**
     * Press back button
     */
    async pressBack() {
        await this.adbCommand('shell input keyevent KEYCODE_BACK');
        console.log('🔙 Pressed back button');
        await this.sleep(200);
    }

    /**
     * Press home button
     */
    async pressHome() {
        await this.adbCommand('shell input keyevent KEYCODE_HOME');
        console.log('🏠 Pressed home button');
        await this.sleep(200);
    }

    /**
     * Recognize text from screenshot using OCR
     */
    async recognizeText(imagePath = null, options = {}) {
        try {
            const imgPath = imagePath || this.screenshotPath;
            
            if (!fs.existsSync(imgPath)) {
                throw new Error(`Image file not found: ${imgPath}`);
            }
            
            const {
                data: { text, words, lines }
            } = await Tesseract.recognize(imgPath, 'eng', {
                logger: m => {
                    if (options.verbose) {
                        console.log(`OCR Progress: ${Math.round(m.progress * 100)}%`);
                    }
                }
            });

            const result = {
                text: text.trim(),
                words: words.map(w => ({
                    text: w.text,
                    confidence: w.confidence,
                    bbox: w.bbox
                })),
                lines: lines.map(l => ({
                    text: l.text,
                    confidence: l.confidence,
                    bbox: l.bbox
                }))
            };

            if (options.verbose) {
                console.log('📝 Recognized text:', result.text);
            }

            return result;
        } catch (error) {
            console.error(`❌ OCR error: ${error.message}`);
            throw error;
        }
    }

    /**
     * Find text on screen and return its position
     */
    async findText(searchText, imagePath = null, threshold = 0.7) {
        try {
            const ocrResult = await this.recognizeText(imagePath, { verbose: false });
            
            // Search for the text in recognized words/lines
            const foundWords = ocrResult.words.filter(word => 
                word.text.toLowerCase().includes(searchText.toLowerCase())
            );

            if (foundWords.length === 0) {
                return null;
            }

            // Return the first match with its bounding box
            const match = foundWords[0];
            const centerX = (match.bbox.x0 + match.bbox.x1) / 2;
            const centerY = (match.bbox.y0 + match.bbox.y1) / 2;

            return {
                text: match.text,
                x: Math.round(centerX),
                y: Math.round(centerY),
                bbox: match.bbox,
                confidence: match.confidence
            };
        } catch (error) {
            console.error(`❌ Find text error: ${error.message}`);
            throw error;
        }
    }

    /**
     * Find and click on text
     */
    async findAndClick(searchText, imagePath = null) {
        try {
            await this.takeScreenshot();
            const found = await this.findText(searchText, this.screenshotPath);
            
            if (!found) {
                console.log(`❌ Text "${searchText}" not found on screen`);
                return false;
            }

            console.log(`✅ Found "${found.text}" at (${found.x}, ${found.y})`);
            await this.click(found.x, found.y);
            return true;
        } catch (error) {
            console.error(`❌ Find and click error: ${error.message}`);
            return false;
        }
    }

    /**
     * Get device screen size
     */
    async getScreenSize() {
        try {
            const output = await this.adbCommand('shell wm size');
            const match = output.match(/(\d+)x(\d+)/);
            if (match) {
                return {
                    width: parseInt(match[1]),
                    height: parseInt(match[2])
                };
            }
            throw new Error('Could not parse screen size');
        } catch (error) {
            console.error(`❌ Get screen size error: ${error.message}`);
            throw error;
        }
    }

    /**
     * Wait for specified milliseconds
     */
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    /**
     * Crop screenshot to specific region
     */
    async cropScreenshot(x, y, width, height, outputPath = null) {
        try {
            await this.takeScreenshot();
            const output = outputPath || path.join(__dirname, 'screenshot_cropped.png');
            
            await sharp(this.screenshotPath)
                .extract({ left: x, top: y, width, height })
                .toFile(output);
            
            console.log(`✂️  Cropped screenshot saved to: ${output}`);
            return output;
        } catch (error) {
            console.error(`❌ Crop error: ${error.message}`);
            throw error;
        }
    }

    /**
     * Take screenshot and mark a coordinate point for visualization
     * Useful for finding coordinates - marks the point on the screenshot
     */
    async markCoordinate(x, y, outputPath = null) {
        try {
            await this.takeScreenshot();
            const output = outputPath || path.join(__dirname, 'screenshot_marked.png');
            
            // Create a red circle marker at the coordinate
            const marker = sharp({
                create: {
                    width: 20,
                    height: 20,
                    channels: 4,
                    background: { r: 255, g: 0, b: 0, alpha: 1 }
                }
            }).png();
            
            // Overlay the marker on the screenshot
            await sharp(this.screenshotPath)
                .composite([{
                    input: await marker.toBuffer(),
                    left: Math.max(0, x - 10),
                    top: Math.max(0, y - 10)
                }])
                .toFile(output);
            
            console.log(`📍 Marked coordinate (${x}, ${y}) on screenshot: ${output}`);
            return output;
        } catch (error) {
            console.error(`❌ Mark coordinate error: ${error.message}`);
            throw error;
        }
    }
}

// Example usage
async function main() {
    const automation = new BlueStacksAutomation();
    
    try {
        // Check connection
        await automation.checkConnection();
        
        // Get screen size
        const screenSize = await automation.getScreenSize();
        console.log(`📱 Screen size: ${screenSize.width}x${screenSize.height}`);
        
        // Example: Take a screenshot
        await automation.takeScreenshot();
        
        // Example: Recognize text from screenshot
        const ocrResult = await automation.recognizeText(null, { verbose: true });
        console.log('\n📝 Full recognized text:');
        console.log(ocrResult.text);
        
        // Example: Find specific text and click on it
        // await automation.findAndClick('Start');
        
        // Example: Click on specific coordinates
        // await automation.click(500, 300);
        
        // Example: Swipe
        // await automation.swipe(500, 1000, 500, 500);
        
    } catch (error) {
        console.error('❌ Error:', error.message);
        console.log('\n💡 Tips:');
        console.log('1. Make sure BlueStacks is running');
        console.log('2. Enable ADB debugging in BlueStacks settings');
        console.log('3. Make sure ADB is installed and in your PATH');
        console.log('4. Try running: adb devices (to see if device is detected)');
    }
}

// Run if executed directly
if (require.main === module) {
    main();
}

module.exports = BlueStacksAutomation;

