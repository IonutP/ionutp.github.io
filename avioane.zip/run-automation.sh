#!/bin/bash

# BlueStacks Automation Script Launcher for macOS/Linux
# This script runs the car-click-automation.js script

echo "========================================"
echo "BlueStacks Automation Launcher"
echo "========================================"
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "[ERROR] Node.js is not installed or not in PATH"
    echo "Please install Node.js from https://nodejs.org/"
    exit 1
fi

# Get the directory where the script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Check if node_modules exists (dependencies installed)
if [ ! -d "node_modules" ]; then
    echo "[WARNING] Dependencies not installed. Installing now..."
    npm install
    if [ $? -ne 0 ]; then
        echo "[ERROR] Failed to install dependencies"
        exit 1
    fi
    echo ""
fi

# Run the automation script
echo "Starting automation..."
echo ""
node car-click-automation.js

# Check exit code
EXIT_CODE=$?
if [ $EXIT_CODE -ne 0 ]; then
    echo ""
    echo "[ERROR] Script exited with error code $EXIT_CODE"
    exit $EXIT_CODE
fi

echo ""
echo "Script completed successfully."
