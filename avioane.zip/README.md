# BlueStacks Game Automation

Automation script for BlueStacks emulator that automates clicking and upgrading in a game.

## Features

- Automates clicking on car image every second
- Detects when upgrade button turns blue/active
- Clicks upgrade button when available
- Performs OCR to check game state and amounts
- Automatic game reset when needed
- Image preprocessing for better OCR accuracy

## Prerequisites

1. **Node.js** (v14 or higher) - [Download](https://nodejs.org/)
2. **BlueStacks** emulator installed and running
3. **ADB (Android Debug Bridge)** installed and in PATH
4. **ADB Debugging enabled** in BlueStacks

### Platform Support

✅ **Windows** - Fully supported  
✅ **macOS** - Fully supported  
✅ **Linux** - Fully supported

The script automatically detects your operating system and uses the appropriate ADB paths.

## Setup

### 1. Install Dependencies

```bash
npm install
```

### 2. Enable ADB Debugging in BlueStacks

1. Open BlueStacks
2. Go to Settings → Advanced → Enable Android Debug Bridge (ADB)
3. Note the port number (usually 5555)

### 3. Install ADB (Android Debug Bridge)

#### Windows

1. Download [Android SDK Platform Tools](https://developer.android.com/studio/releases/platform-tools)
2. Extract the zip file
3. Add the `platform-tools` folder to your system PATH:
   - Open System Properties → Environment Variables
   - Edit the `Path` variable
   - Add the full path to `platform-tools` folder (e.g., `C:\platform-tools`)
4. Or place `adb.exe` in a folder already in your PATH

#### macOS/Linux

```bash
# macOS (using Homebrew)
brew install android-platform-tools

# Or download from: https://developer.android.com/studio/releases/platform-tools
# Then add to PATH in your ~/.zshrc or ~/.bashrc:
# export PATH=$PATH:/path/to/platform-tools
```

### 4. Verify ADB Connection

Open a terminal/command prompt and run:

```bash
adb devices
```

You should see your BlueStacks device listed (e.g., `emulator-5554`).

**If you see "List of devices attached" with nothing below it, or "No devices found":**
- See the [ADB Troubleshooting](#adb-connection-issues) section below

## Usage

### Main Automation Script

Run the main automation script:

```bash
node car-click-automation.js
```

### Selecting a Specific BlueStacks Instance

If you have multiple BlueStacks instances, you can specify which one to use:

**Option 1: Environment Variable**

**Windows (PowerShell):**
```powershell
$env:BLUESTACKS_DEVICE_ID="emulator-5556"
node car-click-automation.js
```

**Windows (CMD):**
```cmd
set BLUESTACKS_DEVICE_ID=emulator-5556
node car-click-automation.js
```

**macOS/Linux:**
```bash
BLUESTACKS_DEVICE_ID=emulator-5556 node car-click-automation.js
```

**Option 2: Check available devices first**
```bash
adb devices
```

Then set the device ID:

**Windows (PowerShell):**
```powershell
$env:BLUESTACKS_DEVICE_ID="emulator-5556"
node car-click-automation.js
```

**Windows (CMD):**
```cmd
set BLUESTACKS_DEVICE_ID=emulator-5556
node car-click-automation.js
```

**macOS/Linux:**
```bash
export BLUESTACKS_DEVICE_ID=emulator-5556
node car-click-automation.js
```

If no device ID is specified, the script will automatically use the first device found in `adb devices`.

The script will:
1. Start with a reset to ensure the game is in the correct state
2. Continuously click the car image
3. Check if the upgrade button is blue/active
4. Click the upgrade button when available
5. Perform OCR checks to determine next actions
6. Reset the game automatically when needed

**To stop the script:** Press `Ctrl+C`

### Configuration

The script uses hardcoded coordinates that were configured for a specific game screen. Key coordinates are defined in `car-click-automation.js`:

- **Start click**: (150, 375) - Car image to click
- **Upgrade button**: (220, 370) - Button to check and click when blue
- **Reset clicks**: 
  - First: (260, 945)
  - Second: (585, 1013)
  - Third: (260, 845)

### Configurable Variables

You can edit the following variables directly in `car-click-automation.js` at the top of the `CarClickAutomation` class to customize behavior:

- `this.resetTargetAmount`: The maximum amount (e.g., 12) that the button OCR should show after a reset for it to be considered successful. Reset succeeds if amount <= this value.
- `this.timerThreshold`: The threshold in seconds for the timer check at step "10/20". If the timer is greater than this value, a reset will occur; otherwise, the automation will stop.
- `this.clickDelay`: The delay in milliseconds for clicks and waits throughout the automation (default: 800ms). Adjust this to make the script faster or slower.

### Test Scripts

There are several test scripts available:

- `test-reset-only.js` - Test only the reset functionality
- `test-reset-second-click.js` - Test and visualize second reset click
- `test-reset-third-click.js` - Test and visualize third reset click

## How It Works

1. **Button Detection**: Uses both color detection and OCR to detect when the upgrade button is active
2. **OCR Processing**: 
   - Preprocesses images (converts background to black, text to white)
   - Sets DPI to 300 for better OCR accuracy
   - Extracts amounts and text from screen regions
3. **Reset Logic**: 
   - Performs 3 clicks in sequence
   - Clicks car image
   - Verifies reset success by checking button amount (should be 10 or 12)
4. **Main Loop**: 
   - Continuously clicks car
   - Checks button state
   - Performs upgrades when available
   - Resets when amount is below threshold

## File Structure

- `car-click-automation.js` - Main automation script
- `bluestacks-automation.js` - BlueStacks/ADB interaction class
- `test-reset-only.js` - Reset testing script
- `screenshots/` - Folder for saved screenshots (auto-cleared at start)
- `package.json` - Dependencies and project info

## Troubleshooting

### ADB Connection Issues

#### Device Not Showing Up

If you see "No devices found" or the device list is empty:

1. **Make sure BlueStacks is running**
   - Open BlueStacks and ensure it's fully loaded

2. **Verify ADB debugging is enabled in BlueStacks**
   - Open BlueStacks
   - Go to Settings → Advanced → Enable Android Debug Bridge (ADB)
   - Note the port number (usually 5555)

3. **Restart ADB Server** (This fixes most connection issues)

   **Windows (PowerShell/CMD):**
   ```cmd
   adb kill-server
   adb start-server
   adb devices
   ```

   **macOS/Linux:**
   ```bash
   adb kill-server && adb start-server
   adb devices
   ```

4. **Check if device appears:**
   ```bash
   adb devices
   ```
   You should see something like:
   ```
   List of devices attached
   emulator-5554    device
   ```

5. **If still not working, try connecting manually:**

   **Windows:**
   ```cmd
   adb connect 127.0.0.1:5555
   adb devices
   ```

   **macOS/Linux:**
   ```bash
   adb connect 127.0.0.1:5555
   adb devices
   ```
   (Replace 5555 with the port number shown in BlueStacks settings)

6. **Check if ADB is in PATH:**
   ```bash
   adb version
   ```
   If this fails, ADB is not in your PATH. See the [Install ADB](#3-install-adb-android-debug-bridge) section above.

7. **Windows-specific: Check if ADB is blocked by firewall**
   - Windows Firewall may block ADB connections
   - Allow `adb.exe` through Windows Firewall if prompted

8. **Multiple BlueStacks instances:**
   - If you have multiple BlueStacks instances, make sure you're connecting to the correct one
   - Check all instances: `adb devices` (should list all)
   - Use the device ID with the environment variable (see [Usage](#usage) section)

#### ADB Server Won't Start

If `adb start-server` fails:

1. **Check if another process is using ADB:**
   - Close any other programs using ADB (Android Studio, other automation tools)
   - On Windows: Check Task Manager for `adb.exe` processes

2. **Kill all ADB processes and restart:**

   **Windows:**
   ```cmd
   taskkill /F /IM adb.exe
   adb start-server
   ```

   **macOS/Linux:**
   ```bash
   killall adb
   adb start-server
   ```

3. **Check ADB permissions (Linux only):**
   ```bash
   sudo chmod +x /path/to/adb
   ```

#### Connection Drops During Script Execution

If the device disconnects while the script is running:

1. **Restart ADB server** (see steps above)
2. **Restart BlueStacks**
3. **Check USB/Network connection** (if using network ADB)
4. **Run the script again**

### OCR Not Working

If OCR is not recognizing text correctly:
- The script automatically preprocesses images for better accuracy
- Check the `screenshots/` folder to see what OCR is seeing
- You may need to adjust coordinates in the script

### Script Stops Unexpectedly

- Check console output for error messages
- Verify BlueStacks is still running
- Ensure the game screen hasn't changed layout

## Dependencies

- `tesseract.js` - OCR text recognition
- `sharp` - Image processing and manipulation
- Node.js built-in modules (`child_process`, `fs`, `path`)

## Notes

- Screenshots are saved in the `screenshots/` folder
- The folder is automatically cleared at the start of each run
- Button check and OCR screenshots are temporary and deleted after processing
- All clicks have a configurable delay (default: 800ms) - see Configurable Variables section

## License

This project is for personal/educational use.

