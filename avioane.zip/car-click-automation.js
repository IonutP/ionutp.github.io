const BlueStacksAutomation = require('./bluestacks-automation');
const sharp = require('sharp');
const path = require('path');
const fs = require('fs');
const { exec } = require('child_process');
const readline = require('readline');

/**
 * Automation: Click car image every second, check if button turns blue, click if blue
 * With reset functionality
 */
class CarClickAutomation {
    constructor(deviceId = null) {
        // Get device ID from environment variable or parameter
        const emulatorDeviceId = deviceId || process.env.BLUESTACKS_DEVICE_ID || null;
        this.bot = new BlueStacksAutomation(emulatorDeviceId);
        this.screenshotsDir = path.join(__dirname, 'screenshots');
        
        // ============================================
        // CONFIGURABLE VARIABLES - Edit these values
        // ============================================
        this.resetTargetAmount = 10;  // Maximum amount for reset verification (reset succeeds if amount <= this value)
        this.timerThreshold = 5;      // Timer threshold in seconds (if > this value, reset at step 10/20)
        this.amountThreshold = 18;    // Amount threshold for step 2/10 check (if amount < this value, reset)
        this.finalStepTarget = '20/30'; // Final step target: '15/20' or '10/20' (automation stops when this is reached)
        this.clickDelay = 1000;       // Delay in milliseconds for clicks and waits (default: 1000ms = 1s)
        this.resetClicksDelay = 50;   // Delay in milliseconds between reset clicks 1, 2, and 3 (default: 20ms for fast clicking)
        // ============================================
        
        // Coordinates for the two clicks
        this.startClickX = 150;   // First click - "dispecer 1 - start"
        this.startClickY = 375;   // First click - "dispecer 1 - start"
        
        // Reset action - 3 click process
        // Options: 'click' with coordinates, or 'back' for back button
        this.resetAction = 'click'; // 'click' or 'back'
        this.resetButtonX = 260; // X coordinate for first reset click
        this.resetButtonY = 945; // Y coordinate for first reset click
        this.resetButton2X = 260 + 300 + 20 + 3 + 2; // X coordinate for second reset click (585)
        this.resetButton2Y = 945 + 40 + 20 + 3 + 5; // Y coordinate for second reset click (1013)
        this.resetButton3X = 260; // X coordinate for third reset click - same X as first
        this.resetButton3Y = 945 - 300 + 200; // Y coordinate for third reset click (845)
        
        // Additional clicks after timer check
        this.postTimerClick1X = 260; // X coordinate for first post-timer click (same as first reset click)
        this.postTimerClick1Y = 945 - 60; // Y coordinate for first post-timer click (885, 60px above first reset click)
        this.postTimerClick2X = 220; // X coordinate for second post-timer click (same X as blue button)
        this.postTimerClick2Y = 370 + 20; // Y coordinate for second post-timer click (390, 20px below blue button)
        
        // OCR region to check amount after reset (to be set)
        this.resetOcrX = null; // X coordinate for OCR region after reset
        this.resetOcrY = null; // Y coordinate for OCR region after reset
        this.resetOcrWidth = null; // Width for OCR region after reset
        this.resetOcrHeight = null; // Height for OCR region after reset
        
        // Button region to check - "dispecer 1 - upgrade" button
        this.buttonX = 220;       // X coordinate of upgrade button area
        this.buttonY = 370;       // Y coordinate of upgrade button area  
        this.buttonWidth = 120;   // Width of button region to check
        this.buttonHeight = 25;   // Height of button region to check (decreased by 5)
        
        // OCR region above the button (same x, same width, same height, but above)
        this.ocrAboveOffset = 40; // How many pixels above the button to check
        this.ocrAboveX = 220;     // Same X coordinate
        this.ocrAboveY = 370 - 40 + 5 + 5; // Button Y minus offset plus 5 plus 5 more (340)
        this.ocrAboveWidth = 120;  // Same width
        this.ocrAboveHeight = 25;  // Same height
        
        // Second OCR region (when text starts with "2")
        this.ocrSecondX = 120 - 10; // X coordinate for second OCR (110)
        this.ocrSecondY = 375 + 30 - 5; // 30 pixels below first click minus 5 (400)
        this.ocrSecondWidth = 50 + 10; // Width for second OCR (60)
        this.ocrSecondHeight = 25;  // Same height as button
        
        this.running = false;
        this.paused = false;
        this.startTime = null; // Track when automation starts (after successful reset)
        this.pauseStartTime = null; // Track when pause started
        this.totalPausedTime = 0; // Track total paused time to adjust startTime
    }

    /**
     * Check if button is blue by analyzing the button region
     * Returns true if button appears to be blue/active
     */
    async isButtonBlue() {
        try {
            // Take screenshot
            await this.bot.takeScreenshot();
            const screenshotPath = this.bot.screenshotPath;
            
            // Crop the button region to temp file
            const buttonCropPath = path.join(this.screenshotsDir, `button_check_temp_${Date.now()}.png`);
            await sharp(screenshotPath)
                .extract({ 
                    left: this.buttonX, 
                    top: this.buttonY, 
                    width: this.buttonWidth, 
                    height: this.buttonHeight 
                })
                .toFile(buttonCropPath);
            
            // Analyze the cropped image to detect blue color
            const image = sharp(buttonCropPath);
            const stats = await image.stats();
            
            // Delete temp file
            try {
                fs.unlinkSync(buttonCropPath);
            } catch (e) {
                // Ignore
            }
            
            // Check if there's significant blue color in the region
            // Blue button typically has high blue channel values
            const channels = stats.channels;
            if (channels.length >= 3) {
                const red = channels[0].mean;
                const green = channels[1].mean;
                const blue = channels[2].mean;
                
                // Blue button detection: blue should be significantly higher than red/green
                // Adjust thresholds based on your button's actual blue color
                const isBlue = blue > 100 && blue > red * 1.2 && blue > green * 1.2;
                
                return isBlue;
            }
            
            return false;
        } catch (error) {
            console.error(`   ❌ Error checking button: ${error.message}`);
            return false;
        }
    }

    /**
     * Alternative: Check button using OCR to see if it has text/amount
     */
    async isButtonActiveWithOCR() {
        try {
            await this.bot.takeScreenshot();
            const screenshotPath = this.bot.screenshotPath;
            
            // Crop button region (don't save screenshot)
            const buttonCropPath = path.join(this.screenshotsDir, `button_ocr_temp_${Date.now()}.png`);
            await sharp(screenshotPath)
                .extract({ 
                    left: this.buttonX, 
                    top: this.buttonY, 
                    width: this.buttonWidth, 
                    height: this.buttonHeight 
                })
                .toFile(buttonCropPath);
            
            // Perform OCR on button region
            const ocrResult = await this.bot.recognizeText(buttonCropPath, { verbose: false });
            
            // Delete temp screenshot
            try {
                fs.unlinkSync(buttonCropPath);
            } catch (e) {
                // Ignore
            }
            
            // Check if text contains numbers (amount) - active button usually shows amount
            const hasAmount = /\$?\s*\d+/.test(ocrResult.text);
            const hasText = ocrResult.text.trim().length > 0;
            
            return hasAmount && hasText;
        } catch (error) {
            console.error(`   ❌ Error OCR check: ${error.message}`);
            return false;
        }
    }

    /**
     * Get button OCR amount (10 or 12 for reset check)
     * Preprocesses image to improve OCR accuracy for white text on gray background
     */
    async getButtonOCRAmount() {
        try {
            await this.bot.takeScreenshot();
            const screenshotPath = this.bot.screenshotPath;
            
            // Crop button region to temp file
            const timestamp = Date.now();
            const buttonCropRawPath = path.join(this.screenshotsDir, `button_ocr_raw_temp_${timestamp}.png`);
            await sharp(screenshotPath)
                .extract({ 
                    left: this.buttonX, 
                    top: this.buttonY, 
                    width: this.buttonWidth, 
                    height: this.buttonHeight 
                })
                .toFile(buttonCropRawPath);
            
            // Define buttonCropPath for processed image (temp file)
            const buttonCropPath = path.join(this.screenshotsDir, `button_ocr_temp_${timestamp}.png`);
            
            // Get image stats to find background color
            const image = sharp(buttonCropRawPath);
            const stats = await image.stats();
            
            // Get the most common color (background) from channels
            const channels = stats.channels;
            if (channels.length >= 3) {
                const bgR = Math.round(channels[0].mean);
                const bgG = Math.round(channels[1].mean);
                const bgB = Math.round(channels[2].mean);
                
                // Preprocess image: replace background with black, keep text white
                // Get raw image data
                const { data, info } = await image.raw().toBuffer({ resolveWithObject: true });
                const pixels = new Uint8Array(data);
                
                // Process pixels: replace background-like colors with black, keep others
                const threshold = 30; // Color difference threshold
                for (let i = 0; i < pixels.length; i += info.channels) {
                    const r = pixels[i];
                    const g = pixels[i + 1];
                    const b = pixels[i + 2];
                    
                    // Calculate color distance from background
                    const dist = Math.sqrt(
                        Math.pow(r - bgR, 2) + 
                        Math.pow(g - bgG, 2) + 
                        Math.pow(b - bgB, 2)
                    );
                    
                    // If pixel is close to background color, make it black
                    // Otherwise, make it white (for text)
                    if (dist < threshold) {
                        pixels[i] = 0;     // R = black
                        pixels[i + 1] = 0; // G = black
                        pixels[i + 2] = 0; // B = black
                    } else {
                        pixels[i] = 255;     // R = white
                        pixels[i + 1] = 255; // G = white
                        pixels[i + 2] = 255; // B = white
                    }
                }
                
                // Save processed image with proper DPI for OCR
                await sharp(pixels, {
                    raw: {
                        width: info.width,
                        height: info.height,
                        channels: info.channels
                    }
                })
                .withMetadata({ density: 300 }) // Set DPI to 300 for better OCR
                .toFile(buttonCropPath);
                
            } else {
                // Fallback: simple threshold if we can't get stats
                await sharp(buttonCropRawPath)
                    .greyscale()
                    .threshold(128)
                    .withMetadata({ density: 300 }) // Set DPI to 300 for better OCR
                    .toFile(buttonCropPath);
            }
            
            // Perform OCR on preprocessed button region
            const ocrResult = await this.bot.recognizeText(buttonCropPath, { verbose: false });
            
            // Extract number from OCR text
            const match = ocrResult.text.match(/\$?\s*(\d+)/);
            
            // Keep debug files for first few attempts to help diagnose issues
            const keepDebugFiles = false; // Set to true to keep OCR debug images
            
            if (!keepDebugFiles) {
                // Delete temp files
                try {
                    fs.unlinkSync(buttonCropRawPath);
                    fs.unlinkSync(buttonCropPath);
                } catch (e) {
                    // Ignore
                }
            } else {
                // Keep files for debugging - rename them
                try {
                    const debugRawPath = path.join(this.screenshotsDir, `button_ocr_raw_debug_${timestamp}.png`);
                    const debugProcessedPath = path.join(this.screenshotsDir, `button_ocr_processed_debug_${timestamp}.png`);
                    fs.renameSync(buttonCropRawPath, debugRawPath);
                    fs.renameSync(buttonCropPath, debugProcessedPath);
                } catch (e) {
                    // Ignore
                }
            }
            
            if (match) {
                const amount = parseInt(match[1], 10);
                return amount;
            }
            
            // Log OCR text for debugging when no match found
            if (ocrResult.text.trim().length > 0) {
                console.log(`   🔍 OCR text (no number match): "${ocrResult.text.trim()}"`);
            }
            
            return null;
        } catch (error) {
            console.error(`   ❌ Error getting button amount: ${error.message}`);
            return null;
        }
    }

    /**
     * Reset the game until OCR shows amount 10 or 12
     * Process: 3 clicks -> OCR area -> check amount -> loop if not 10 or 12
     */
    async resetGame() {
        console.log(`\n   🔄 RESET: Starting reset process...`);
        console.log(`   📋 Goal: Reset until OCR shows amount <= ${this.resetTargetAmount}`);
        
        let resetAttempts = 0;
        const maxResetAttempts = 30; // Prevent infinite loops
        
        while (resetAttempts < maxResetAttempts) {
            // Check if paused and wait (only if running is set, otherwise skip pause check)
            if (this.running) {
                await this.waitWhilePaused();
                if (!this.running) return false;
            }
            
            resetAttempts++;
            console.log(`\n   🔄 Reset attempt ${resetAttempts}/${maxResetAttempts}`);
            
            // Step 1: First reset click
            if (this.resetButtonX === null || this.resetButtonY === null) {
                console.log(`   ❌ First reset click coordinates not set!`);
                return false;
            }
            await this.bot.click(this.resetButtonX, this.resetButtonY, this.resetClicksDelay);
            
            // Step 2: Second reset click
            if (this.resetButton2X === null || this.resetButton2Y === null) {
                console.log(`   ❌ Second reset click coordinates not set!`);
                return false;
            }
            const screen = await this.bot.getScreenSize();
            const secondClickX = Math.min(this.resetButton2X, screen.width - 10);
            await this.bot.click(secondClickX, this.resetButton2Y, this.resetClicksDelay);
            
            // Step 3: Third reset click
            if (this.resetButton3X === null || this.resetButton3Y === null) {
                console.log(`   ❌ Third reset click coordinates not set!`);
                return false;
            }
            const thirdClickX = Math.min(this.resetButton3X, screen.width - 10);
            await this.bot.click(thirdClickX, this.resetButton3Y, this.resetClicksDelay);
            
            // Step 4: Click on car, then make OCR on amount
            await this.bot.click(this.startClickX, this.startClickY, this.clickDelay);
            
            // Step 5: Check button OCR amount to verify reset success
            const buttonAmount = await this.getButtonOCRAmount();
            
            if (buttonAmount !== null) {
                console.log(`   📊 Button amount detected: ${buttonAmount}`);
                if (buttonAmount <= this.resetTargetAmount) {
                    console.log(`   ✅ Reset successful! Button amount is ${buttonAmount} (<= ${this.resetTargetAmount})`);
                    return true;
                } else {
                    console.log(`   ⚠️  Button amount is ${buttonAmount}, not <= ${this.resetTargetAmount}. Retrying reset...`);
                }
            } else {
                console.log(`   ⚠️  Could not read button amount (OCR returned null). Retrying reset...`);
                // Save screenshot for debugging if OCR fails multiple times
                if (resetAttempts % 5 === 0) {
                    const debugScreenshot = path.join(this.screenshotsDir, `reset_debug_attempt_${resetAttempts}.png`);
                    try {
                        await this.bot.takeScreenshot(debugScreenshot);
                        console.log(`   📸 Debug screenshot saved: ${debugScreenshot}`);
                    } catch (e) {
                        // Ignore screenshot errors
                    }
                }
            }
            
            await this.bot.sleep(this.clickDelay);
        }
        
        console.log(`   ❌ Reset failed after ${maxResetAttempts} attempts`);
        return false;
    }

    /**
     * Start the game by clicking on steps
     */
    async startGame() {
        console.log(`\n   ▶️  START: Starting the game...`);
        // TODO: Implement start game functionality
        // For now, just log
        await this.bot.sleep(this.clickDelay);
    }

    /**
     * Setup keyboard input handling for pause/resume
     */
    setupKeyboardHandling() {
        // Only setup if stdin is a TTY (interactive terminal)
        if (!process.stdin.isTTY) {
            return;
        }

        // Set stdin to raw mode for keypress detection
        if (process.stdin.setRawMode) {
            process.stdin.setRawMode(true);
        }
        process.stdin.resume();
        process.stdin.setEncoding('utf8');

        // Handle keypress events
        process.stdin.on('data', (key) => {
            // Handle Ctrl+C
            if (key === '\u0003') {
                this.stop();
                setTimeout(() => process.exit(0), 1000);
                return;
            }

            // Handle 'p' or 'P' for pause/resume
            if (key === 'p' || key === 'P') {
                this.togglePause();
            }
        });
    }

    /**
     * Toggle pause state
     */
    togglePause() {
        if (!this.running) {
            return; // Can't pause if not running
        }

        this.paused = !this.paused;

        if (this.paused) {
            this.pauseStartTime = Date.now();
            console.log('\n⏸️  PAUSED - Press "P" to resume');
        } else {
            if (this.pauseStartTime) {
                const pausedDuration = Date.now() - this.pauseStartTime;
                this.totalPausedTime += pausedDuration;
                this.pauseStartTime = null;
                // Adjust startTime to account for paused time
                if (this.startTime) {
                    this.startTime += pausedDuration;
                }
            }
            console.log('\n▶️  RESUMED - Press "P" to pause');
        }
    }

    /**
     * Wait while paused
     */
    async waitWhilePaused() {
        while (this.paused && this.running) {
            await this.bot.sleep(100); // Check every 100ms
        }
    }

    /**
     * Sleep with pause check - allows pausing during long waits
     */
    async sleepWithPauseCheck(ms) {
        const startTime = Date.now();
        while (Date.now() - startTime < ms && this.running) {
            await this.waitWhilePaused();
            if (!this.running) break;
            
            const remaining = ms - (Date.now() - startTime);
            if (remaining > 0) {
                await this.bot.sleep(Math.min(remaining, 100)); // Check every 100ms
            }
        }
    }

    /**
     * Main automation loop
     */
    async run() {
        try {
            // Clear screenshots folder at start
            const screenshotsDir = path.join(__dirname, 'screenshots');
            if (fs.existsSync(screenshotsDir)) {
                const files = fs.readdirSync(screenshotsDir);
                files.forEach(file => {
                    try {
                        fs.unlinkSync(path.join(screenshotsDir, file));
                    } catch (e) {
                        // Ignore errors
                    }
                });
                console.log('🧹 Cleared screenshots folder\n');
            }
            
            console.log('🔌 Connecting to BlueStacks...');
            await this.bot.checkConnection();
            
            const screen = await this.bot.getScreenSize();
            console.log(`📱 Screen size: ${screen.width}x${screen.height}\n`);
            
            // Step 1: Start with reset
            console.log('🔄 Starting with reset...\n');
            const resetSuccess = await this.resetGame();
            
            if (!resetSuccess) {
                console.log('❌ Reset failed. Cannot continue automation.');
                return;
            }
            
            // Step 2: Verify button amount is 10 or 12 after reset
            console.log('\n🔍 Verifying button amount after reset...');
            const buttonAmount = await this.getButtonOCRAmount();
            
            if (buttonAmount === null || buttonAmount > this.resetTargetAmount) {
                console.log(`❌ Button amount is ${buttonAmount}, expected <= ${this.resetTargetAmount}. Cannot start automation.`);
                return;
            }
            
            console.log(`✅ Button amount verified: ${buttonAmount}. Starting automation...\n`);
            
            // Setup keyboard handling for pause/resume
            this.setupKeyboardHandling();
            console.log('💡 Tip: Press "P" to pause/resume the automation\n');
            
            // Record start time when automation actually begins
            this.startTime = Date.now();
            
            this.running = true;
            let iteration = 0;
            
            while (this.running) {
                // Check if paused and wait
                await this.waitWhilePaused();
                if (!this.running) break;
                
                // Step 1: Click start button
                await this.bot.click(this.startClickX, this.startClickY, this.clickDelay);
                
                // Step 2: Check if upgrade button is blue/active
                
                // Try both methods: color detection and OCR
                const isBlue = await this.isButtonBlue();
                const isActiveOCR = await this.isButtonActiveWithOCR();
                
                // Step 3: If button is blue/active, click it and perform OCR above
                if (isBlue || isActiveOCR) {
                    console.log(`\n   ✅ BUTTON IS BLUE/ACTIVE!`);
                    
                    // Click the button at its center
                        const buttonClickX = this.buttonX + this.buttonWidth / 2;
                        const buttonClickY = this.buttonY + this.buttonHeight / 2;
                        await this.bot.click(buttonClickX, buttonClickY, this.clickDelay);
                    
                    // Step 4: Perform OCR on region above the button
                    await this.bot.takeScreenshot();
                    const screenshotPath = this.bot.screenshotPath;
                    
                    // Crop the OCR region above to temp file
                    const ocrCropPath = path.join(this.screenshotsDir, `ocr_above_temp_${Date.now()}.png`);
                    await sharp(screenshotPath)
                        .extract({ 
                            left: this.ocrAboveX, 
                            top: this.ocrAboveY, 
                            width: this.ocrAboveWidth, 
                            height: this.ocrAboveHeight 
                        })
                        .toFile(ocrCropPath);
                    
                    // Perform OCR
                    const ocrResult = await this.bot.recognizeText(ocrCropPath, { verbose: false });
                    const ocrText = ocrResult.text.trim();
                    
                    // Delete temp screenshots
                    try {
                        fs.unlinkSync(ocrCropPath);
                        fs.unlinkSync(screenshotPath);
                    } catch (e) {
                        // Ignore
                    }
                    
                    console.log(`\n   📝 OCR Result above button: "${ocrText}"`);
                    
                    // Check if step matches final target - automation complete
                    const isFinalStep = ocrText.includes(this.finalStepTarget);
                    if (isFinalStep) {
                        console.log(`\n   ✅ Step is ${this.finalStepTarget} - Automation complete!`);
                        this.running = false;
                        this.showElapsedTime();
                        this.showCompletionAlert();
                        this.cleanupAndExit();
                        return;
                    }
                    
                    // Check if step is "10/20" - check timer and reset if needed
                    const isStepTenTwenty = ocrText.includes('10/20');
                    if (isStepTenTwenty) {
                        console.log(`\n   ✅ Step is 10/20 - Checking timer...`);
                        
                        // Wait 10 seconds before checking timer
                        console.log(`   ⏳ Waiting 10 seconds before checking timer...`);
                        await this.sleepWithPauseCheck(10000);
                        
                        // Take screenshot for timer OCR
                        await this.bot.takeScreenshot();
                        const timerScreenshotPath = this.bot.screenshotPath;
                        
                        // Timer OCR area: X is buttonX + 30, Y is buttonY + 30, width decreased by 30
                        const timerOcrX = this.buttonX + 30;
                        const timerOcrY = this.buttonY + 30;
                        const timerOcrWidth = this.buttonWidth - 30;
                        const timerOcrHeight = this.buttonHeight;
                        
                        // Crop the timer OCR region to temp file
                        const timerOcrCropPath = path.join(this.screenshotsDir, `timer_ocr_temp_${Date.now()}.png`);
                        await sharp(timerScreenshotPath)
                            .extract({ 
                                left: timerOcrX, 
                                top: timerOcrY, 
                                width: timerOcrWidth, 
                                height: timerOcrHeight 
                            })
                            .toFile(timerOcrCropPath);
                        
                        // Perform OCR on timer region
                        const timerOcrResult = await this.bot.recognizeText(timerOcrCropPath, { verbose: false });
                        const timerOcrText = timerOcrResult.text.trim();
                        
                        // Delete temp screenshots after OCR
                        try {
                            fs.unlinkSync(timerOcrCropPath);
                            fs.unlinkSync(timerScreenshotPath);
                        } catch (e) {
                            // Ignore
                        }
                        
                        console.log(`   📝 Timer OCR Result: "${timerOcrText}"`);
                        
                        // Extract seconds from timer (format: 00:05, 00:06, etc.)
                        // Look for pattern like "00:05" or ":05" and extract the seconds part
                        const timerMatch = timerOcrText.match(/:(\d+)/);
                        const timerSeconds = timerMatch ? parseInt(timerMatch[1], 10) : null;
                        
                        if (timerSeconds !== null) {
                            console.log(`   ⏱️  Timer seconds: ${timerSeconds}`);
                            
                            // If timer is > threshold, reset; otherwise perform post-timer clicks
                            if (timerSeconds > this.timerThreshold) {
                                console.log(`   ⚠️  Timer is ${timerSeconds} seconds (> ${this.timerThreshold}), resetting...`);
                                await this.resetGame();
                                // After reset, continue the loop
                                continue;
                            } else {
                                console.log(`   ✅ Timer is ${timerSeconds} seconds (<= ${this.timerThreshold}), preparing for post-timer clicks...`);
                                
                                // Step 1: Click on the car
                                console.log(`   👆 Clicking on car at (${this.startClickX}, ${this.startClickY})...`);
                                await this.bot.click(this.startClickX, this.startClickY, this.clickDelay);
                                
                                // Step 2: Wait 10 seconds
                                console.log(`   ⏳ Waiting 10 seconds before post-timer clicks...`);
                                await this.sleepWithPauseCheck(10000);
                                
                                // Step 3: Perform first post-timer click
                                console.log(`   👆 Post-timer click 1 at (${this.postTimerClick1X}, ${this.postTimerClick1Y})`);
                                await this.bot.click(this.postTimerClick1X, this.postTimerClick1Y, this.clickDelay);
                                await this.bot.sleep(this.clickDelay);
                                
                                // Step 4: Perform second post-timer click
                                console.log(`   👆 Post-timer click 2 at (${this.postTimerClick2X}, ${this.postTimerClick2Y})`);
                                await this.bot.click(this.postTimerClick2X, this.postTimerClick2Y, this.clickDelay);
                                await this.bot.sleep(this.clickDelay);
                                
                                // Step 5: Check final step after post-timer clicks
                                console.log(`   🔍 Checking final step after post-timer clicks...`);
                                await this.bot.takeScreenshot();
                                const finalCheckScreenshotPath = this.bot.screenshotPath;
                                
                                // Crop the OCR region above to temp file
                                const finalCheckOcrCropPath = path.join(this.screenshotsDir, `final_check_ocr_temp_${Date.now()}.png`);
                                await sharp(finalCheckScreenshotPath)
                                    .extract({ 
                                        left: this.ocrAboveX, 
                                        top: this.ocrAboveY, 
                                        width: this.ocrAboveWidth, 
                                        height: this.ocrAboveHeight 
                                    })
                                    .toFile(finalCheckOcrCropPath);
                                
                                // Perform OCR
                                const finalCheckOcrResult = await this.bot.recognizeText(finalCheckOcrCropPath, { verbose: false });
                                const finalCheckOcrText = finalCheckOcrResult.text.trim();
                                
                                // Delete temp screenshots
                                try {
                                    fs.unlinkSync(finalCheckOcrCropPath);
                                    fs.unlinkSync(finalCheckScreenshotPath);
                                } catch (e) {
                                    // Ignore
                                }
                                
                                console.log(`   📝 Final step check OCR Result: "${finalCheckOcrText}"`);
                                
                                // Check if step matches final target - automation complete
                                const isFinalStep = finalCheckOcrText.includes(this.finalStepTarget);
                                if (isFinalStep) {
                                    console.log(`\n   ✅ Step is ${this.finalStepTarget} - Automation complete!`);
                                    this.running = false;
                                    this.showElapsedTime();
                                    this.showCompletionAlert();
                                    this.cleanupAndExit();
                                    return;
                                }
                                
                                console.log(`   ✅ Post-timer clicks completed. Now only clicking blue button when active (no car clicks)...`);
                                // Loop: Only check and click blue button (no car clicks) until final step target is reached
                                // Wait 2 seconds before first check (double the delay for efficiency)
                                await this.bot.sleep(this.clickDelay * 2);
                                
                                while (this.running) {
                                    // Check if paused and wait
                                    await this.waitWhilePaused();
                                    if (!this.running) break;
                                    
                                    // Check if upgrade button is blue/active
                                    const isBlue = await this.isButtonBlue();
                                    const isActiveOCR = await this.isButtonActiveWithOCR();
                                    
                                    // If button is blue/active, click it and perform OCR above
                                    if (isBlue || isActiveOCR) {
                                        console.log(`\n   ✅ BUTTON IS BLUE/ACTIVE!`);
                                        
                                        // Click the button at its center
                                        const buttonClickX = this.buttonX + this.buttonWidth / 2;
                                        const buttonClickY = this.buttonY + this.buttonHeight / 2;
                                        await this.bot.click(buttonClickX, buttonClickY, this.clickDelay);
                                        
                                        // Perform OCR on region above the button
                                        await this.bot.takeScreenshot();
                                        const screenshotPath = this.bot.screenshotPath;
                                        
                                        // Crop the OCR region above to temp file
                                        const ocrCropPath = path.join(this.screenshotsDir, `ocr_above_temp_${Date.now()}.png`);
                                        await sharp(screenshotPath)
                                            .extract({ 
                                                left: this.ocrAboveX, 
                                                top: this.ocrAboveY, 
                                                width: this.ocrAboveWidth, 
                                                height: this.ocrAboveHeight 
                                            })
                                            .toFile(ocrCropPath);
                                        
                                        // Perform OCR
                                        const ocrResult = await this.bot.recognizeText(ocrCropPath, { verbose: false });
                                        const ocrText = ocrResult.text.trim();
                                        
                                        // Delete temp screenshots
                                        try {
                                            fs.unlinkSync(ocrCropPath);
                                            fs.unlinkSync(screenshotPath);
                                        } catch (e) {
                                            // Ignore
                                        }
                                        
                                        console.log(`\n   📝 OCR Result above button: "${ocrText}"`);
                                        
                                        // Check if step matches final target - automation complete
                                        const isFinalStep = ocrText.includes(this.finalStepTarget);
                                        if (isFinalStep) {
                                            console.log(`\n   ✅ Step is ${this.finalStepTarget} - Automation complete!`);
                                            this.running = false;
                                            this.showElapsedTime();
                                            this.showCompletionAlert();
                                            this.cleanupAndExit();
                                            return;
                                        }
                                    }
                                    
                                    // Wait 2 seconds before next check (double the delay for efficiency)
                                    await this.bot.sleep(this.clickDelay * 2);
                                }
                                
                                // Exit the main loop
                                break;
                            }
                        } else {
                            console.log(`   ⚠️  Could not extract timer seconds, resetting...`);
                            await this.resetGame();
                            continue;
                        }
                    }
                    
                    // Check if step is "2/10"
                    const isStepTwoTen = ocrText.includes('2/10');
                    
                    if (isStepTwoTen) {
                        // Case 2a: Step is 2/10 - check OCR second amount
                        console.log(`   📍 Step is 2/10`);
                        
                        await this.bot.takeScreenshot();
                        const screenshotPath2 = this.bot.screenshotPath;
                        
                        // Crop the second OCR region to temp file
                        const ocrSecondCropPath = path.join(this.screenshotsDir, `ocr_second_temp_${Date.now()}.png`);
                        await sharp(screenshotPath2)
                            .extract({ 
                                left: this.ocrSecondX, 
                                top: this.ocrSecondY, 
                                width: this.ocrSecondWidth, 
                                height: this.ocrSecondHeight 
                            })
                            .toFile(ocrSecondCropPath);
                        
                        // Perform OCR on second region
                        const ocrResult2 = await this.bot.recognizeText(ocrSecondCropPath, { verbose: false });
                        const ocrText2 = ocrResult2.text.trim();
                        
                        // Delete temp screenshots after OCR
                        try {
                            fs.unlinkSync(ocrSecondCropPath);
                            fs.unlinkSync(screenshotPath2);
                        } catch (e) {
                            // Ignore
                        }
                        
                        console.log(`\n   📝 Second OCR Result: "${ocrText2}"`);
                        
                        // Extract amount from OCR text (format: $xx)
                        const amountMatch = ocrText2.match(/\$?\s*(\d+)/);
                        const amount = amountMatch ? parseInt(amountMatch[1], 10) : null;
                        
                        if (amount !== null) {
                            console.log(`   💰 Amount detected: ${amount}`);
                            
                            // If amount is not >= threshold, reset
                            if (amount < this.amountThreshold) {
                                console.log(`   ⚠️  Amount ${amount} < ${this.amountThreshold}, resetting...`);
                                await this.resetGame();
                                // After reset, continue the loop
                                continue;
                            } else {
                                console.log(`   ✅ Amount ${amount} >= ${this.amountThreshold}, continuing...`);
                                // Continue clicking car and upgrading
                            }
                        } else {
                            console.log(`   ⚠️  Could not extract amount, resetting...`);
                            await this.resetGame();
                            continue;
                        }
                        
                        // Continue the loop instead of stopping
                        await this.bot.sleep(this.clickDelay);
                    } else {
                        // Case 2b: Step is not 2/10 - keep clicking car and button when blue
                        // No reset needed, just continue clicking car and upgrading
                        await this.bot.sleep(this.clickDelay);
                    }
                }
                
                // Wait before next check
                await this.bot.sleep(this.clickDelay);
            }
            
            } catch (error) {
                console.error('\n❌ Error:', error.message);
                this.running = false;
                this.showElapsedTime();
                this.cleanupAndExit(1);
            }
    }

    /**
     * Cleanup and exit the script
     */
    cleanupAndExit(exitCode = 0) {
        // Restore stdin if it was modified
        if (process.stdin.isTTY && process.stdin.setRawMode) {
            process.stdin.setRawMode(false);
        }
        process.stdin.pause();
        
        // Exit after a short delay to allow any async operations to complete
        setTimeout(() => {
            process.exit(exitCode);
        }, 500);
    }

    /**
     * Format elapsed time in a human-readable format
     */
    formatElapsedTime(ms) {
        const seconds = Math.floor(ms / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        
        if (hours > 0) {
            return `${hours}h ${minutes % 60}m ${seconds % 60}s`;
        } else if (minutes > 0) {
            return `${minutes}m ${seconds % 60}s`;
        } else {
            return `${seconds}s`;
        }
    }
    
    /**
     * Show elapsed time since automation started
     */
    showElapsedTime() {
        if (this.startTime !== null) {
            const elapsed = Date.now() - this.startTime;
            const formatted = this.formatElapsedTime(elapsed);
            console.log(`\n   ⏱️  Total time to reach good variant: ${formatted}`);
        }
    }
    
    /**
     * Show alert notification when automation completes
     */
    showCompletionAlert() {
        const isWindows = process.platform === 'win32';
        const isMac = process.platform === 'darwin';
        const isLinux = process.platform === 'linux';
        
        try {
            if (isMac) {
                // macOS: Use osascript to show native alert dialog
                const elapsed = this.startTime ? this.formatElapsedTime(Date.now() - this.startTime) : 'N/A';
                const script = `osascript -e 'display dialog "✅ Automation Complete!\\n\\nTime: ${elapsed}" buttons {"OK"} default button "OK" with icon note with title "BlueStacks Automation"'`;
                exec(script, () => {});
                // Also play sound
                exec('say "Automation complete!"', () => {});
            } else if (isWindows) {
                // Windows: Use msg command or PowerShell
                const elapsed = this.startTime ? this.formatElapsedTime(Date.now() - this.startTime) : 'N/A';
                exec(`powershell -c "[System.Windows.Forms.MessageBox]::Show('✅ Automation Complete!\\n\\nTime: ${elapsed}', 'BlueStacks Automation', 'OK', 'Information')"`, () => {});
            } else if (isLinux) {
                // Linux: Use notify-send or zenity
                const elapsed = this.startTime ? this.formatElapsedTime(Date.now() - this.startTime) : 'N/A';
                exec(`notify-send "BlueStacks Automation" "✅ Automation Complete!\\nTime: ${elapsed}" -i info`, () => {});
            }
        } catch (error) {
            // Silently fail if alert can't be shown
        }
    }
    
    /**
     * Take a screenshot marking the post-timer click locations
     */
    async screenshotPostTimerClicks() {
        try {
            const coordinates = [
                { x: this.postTimerClick1X, y: this.postTimerClick1Y, label: 'Post-Timer Click 1' }
            ];
            
            // Add second click if coordinates are set
            if (this.postTimerClick2X !== null && this.postTimerClick2Y !== null) {
                coordinates.push({ x: this.postTimerClick2X, y: this.postTimerClick2Y, label: 'Post-Timer Click 2' });
            }
            
            // Filter out null coordinates
            const validCoordinates = coordinates.filter(coord => coord.x !== null && coord.y !== null);
            
            if (validCoordinates.length === 0) {
                console.log('⚠️  No post-timer click coordinates set');
                return;
            }
            
            await this.markCoordinatesOnScreenshot(validCoordinates);
        } catch (error) {
            console.error(`❌ Error taking post-timer clicks screenshot: ${error.message}`);
        }
    }
    
    /**
     * Take a screenshot and mark multiple coordinates for visualization
     * Useful for finding coordinates - marks the points on the screenshot
     */
    async markCoordinatesOnScreenshot(coordinates, outputPath = null) {
        try {
            await this.bot.takeScreenshot();
            const output = outputPath || path.join(this.screenshotsDir, `screenshot_marked_${Date.now()}.png`);
            
            // Create markers for each coordinate
            const markers = [];
            const colors = [
                { r: 255, g: 0, b: 0, alpha: 1 },      // Red
                { r: 0, g: 255, b: 0, alpha: 1 },      // Green
                { r: 0, g: 0, b: 255, alpha: 1 },      // Blue
                { r: 255, g: 255, b: 0, alpha: 1 },    // Yellow
                { r: 255, g: 0, b: 255, alpha: 1 },    // Magenta
                { r: 0, g: 255, b: 255, alpha: 1 }     // Cyan
            ];
            
            for (let i = 0; i < coordinates.length; i++) {
                const coord = coordinates[i];
                const color = colors[i % colors.length];
                
                // Create a red circle marker at the coordinate
                const marker = sharp({
                    create: {
                        width: 30,
                        height: 30,
                        channels: 4,
                        background: color
                    }
                }).png();
                
                markers.push({
                    input: await marker.toBuffer(),
                    left: Math.max(0, coord.x - 15),
                    top: Math.max(0, coord.y - 15)
                });
            }
            
            // Overlay all markers on the screenshot
            await sharp(this.bot.screenshotPath)
                .composite(markers)
                .toFile(output);
            
            console.log(`📍 Marked ${coordinates.length} coordinate(s) on screenshot: ${output}`);
            console.log(`   Coordinates:`);
            coordinates.forEach((coord, i) => {
                console.log(`   ${i + 1}. (${coord.x}, ${coord.y})${coord.label ? ` - ${coord.label}` : ''}`);
            });
            
            return output;
        } catch (error) {
            console.error(`❌ Mark coordinates error: ${error.message}`);
            throw error;
        }
    }
    
    stop() {
        console.log('\n🛑 Stopping automation...');
        this.running = false;
        this.paused = false;
        
        // Restore stdin if it was modified
        if (process.stdin.isTTY && process.stdin.setRawMode) {
            process.stdin.setRawMode(false);
        }
        process.stdin.pause();
        
        this.showElapsedTime();
        
        // Clear screenshots folder
        try {
            const screenshotsDir = path.join(__dirname, 'screenshots');
            if (fs.existsSync(screenshotsDir)) {
                const files = fs.readdirSync(screenshotsDir);
                files.forEach(file => {
                    try {
                        fs.unlinkSync(path.join(screenshotsDir, file));
                    } catch (e) {
                        // Ignore errors
                    }
                });
                console.log('🧹 Cleared screenshots folder');
            }
        } catch (error) {
            // Ignore errors when clearing screenshots
        }
    }
}

// Run if executed directly
if (require.main === module) {
    const automation = new CarClickAutomation();
    
    // Test mode: Take screenshot of post-timer click locations
    if (process.env.TEST_POST_TIMER_CLICKS === 'true') {
        (async () => {
            try {
                console.log('🔌 Connecting to BlueStacks...');
                await automation.bot.checkConnection();
                console.log('\n📸 Taking screenshot with post-timer click locations marked...\n');
                await automation.screenshotPostTimerClicks();
                console.log('\n✅ Screenshot saved! Check the screenshots folder.');
                process.exit(0);
            } catch (error) {
                console.error('❌ Error:', error.message);
                process.exit(1);
            }
        })();
    } else {
        // Handle Ctrl+C to stop gracefully
        process.on('SIGINT', () => {
            automation.stop();
            setTimeout(() => process.exit(0), 1000);
        });
        
        // Cleanup on exit
        process.on('exit', () => {
            if (process.stdin.isTTY && process.stdin.setRawMode) {
                process.stdin.setRawMode(false);
            }
            process.stdin.pause();
        });
        
        automation.run();
    }
}

module.exports = CarClickAutomation;

